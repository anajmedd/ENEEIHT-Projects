package com.example.projectapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

public class firstActivity extends AppCompatActivity  implements View.OnClickListener {
    int id;
    final int MSG_CALCUL = 1;
    @Override
    public void onClick(View v) {
        id = v.getId();
        new Thread(r).start();
    }

    final Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {
            return false;
        }
    }){
        public void handleMessage(Message message) {
            if (message.what == MSG_CALCUL) {
                LinearLayout lly = (LinearLayout) findViewById(R.id.layoutlineaire);
                String messageString = (String) message.obj;
                String[] temp = messageString.split(" ");
                // Mise à jour du layout
                Button btn = (Button) findViewById(Integer.parseInt(temp[0]));
                TextView AppName = (TextView) findViewById(Integer.parseInt(temp[0]) + 10000);
                TextView monitor = (TextView) findViewById(Integer.parseInt(temp[0]) + 150000);

                btn.setVisibility(View.GONE);
                AppName.setVisibility(View.GONE);
                monitor.setVisibility(View.GONE);

                View view = createProcessView(Integer.parseInt(temp[0]), temp[1], temp[2]);
                lly.addView(view);

                Toast.makeText(firstActivity.this, "RSS updated", Toast.LENGTH_LONG).show();
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        Intent intent = getIntent();
        LinearLayout lly = (LinearLayout) findViewById(R.id.layoutlineaire);

        // Informations relatives aux processus
        final Intent principalIntent = new Intent(Intent.ACTION_MAIN, null);
        principalIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        // Liste des applications installées.
        final List pkgAppsList = getPackageManager().queryIntentActivities(principalIntent, 0);

        int i = 1;
        int[] ListUID = new int[pkgAppsList.size()];
        String[] ListName = new String[pkgAppsList.size()];
        String[] ListRSS = new String[pkgAppsList.size()];

        for (Object object : pkgAppsList) {
            ResolveInfo info = (ResolveInfo) object;
            String strPackageName = info.activityInfo.applicationInfo.packageName.toString();
            int UID = info.activityInfo.applicationInfo.uid;
            // Lancement de la commande système ps
            Process process = null;
            try {
                process = new ProcessBuilder("ps").start();
            } catch (IOException e) {
                return;
            }
            InputStream in = process.getInputStream();
            Scanner scanner = new Scanner(in);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();

                if (line.startsWith("u0_")) {
                    String[] temp = line.split("\\s+");
                    String packageName = temp[temp.length - 1];

                    if (strPackageName.equals(packageName)) {
                        ListName[i] = strPackageName;
                        ListUID[i] = UID;
                        ListRSS[i] = temp[temp.length - 5];
                        View v = createProcessView(ListUID[i], ListName[i], ListRSS[i]);
                        i++;
                        lly.addView(v);
                    }
                }
            }
        }
    }


    public View createProcessView(int UID, String appname, String monitor) {


        RelativeLayout layout = new RelativeLayout(this);

        // Emplacement des élements widgets
        RelativeLayout.LayoutParams paramsTopLeft =
                new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsTopLeft.addRule(RelativeLayout.ALIGN_PARENT_LEFT,
                RelativeLayout.TRUE);
        paramsTopLeft.addRule(RelativeLayout.ALIGN_PARENT_TOP,
                RelativeLayout.TRUE);

        RelativeLayout.LayoutParams paramsBottomLeft = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsBottomLeft.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
        paramsBottomLeft.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);

        appname = "   [" + UID + "] " + appname;
        monitor = "   RSS:" + monitor;

        TextView processname = new TextView(this);
        processname.setText(appname);

        processname.setId(UID + 10000);

        TextView processmonitor = new TextView(this);
        processmonitor.setText(monitor);
        processmonitor.setId(UID + 150000);
        layout.addView(processname, paramsTopLeft);
        layout.addView(processmonitor, paramsBottomLeft);


        RelativeLayout.LayoutParams paramsTopRight = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsTopRight.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
        paramsTopRight.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);


        Button btn = new Button(this);
        btn.setText(R.string.btn_text);
        btn.setId(UID);
        layout.addView(btn, paramsTopRight);
        btn.setOnClickListener((View.OnClickListener) this);

        return layout;
    }
    Runnable r = new Runnable() {

        public void run() {
            LinearLayout lly = (LinearLayout) findViewById(R.id.layoutlineaire);
            // Informations relatives aux processus.
            // Liste des applications installées.
            final Intent principalIntent = new Intent(Intent.ACTION_MAIN, null);
            principalIntent.addCategory(Intent.CATEGORY_LAUNCHER);
            final List paquetAppList = getPackageManager().queryIntentActivities(principalIntent, 0);
            String appNom_actual;
            String rss_actual;
            int uid_actual = 0;


            for (Object object : paquetAppList) {
                ResolveInfo info = (ResolveInfo) object;
                String strPaquetNom = info.activityInfo.applicationInfo.packageName.toString();
                Log.d("STATE",strPaquetNom.toString());
                Log.d("myTag", "This is my message");


                // Lancement de la commande système ps
                Process processus = null;
                try {
                    processus = new ProcessBuilder("ps").start();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                InputStream input = processus.getInputStream();
                Scanner scanner = new Scanner(input);

                while (scanner.hasNextLine()) {
                    String ligne = scanner.nextLine();
                    if (ligne.startsWith("u0_")) {
                        String[] temp = ligne.split(" \\s+");
                        String packageNom = temp[temp.length - 1];

                        // La mémoire qu’occupe le processus
                        if (strPaquetNom.equals(packageNom)) {
                            uid_actual = info.activityInfo.applicationInfo.uid;

                            if (id == uid_actual) {
                                // Mettre à jour le RSS
                                rss_actual = temp[temp.length - 5];
                                // Mettre à jour le nom
                                appNom_actual = strPaquetNom;
                                // Mise à jour Global
                                String Messagetosend = Integer.toString(uid_actual)
                                        + " " + appNom_actual + " " + rss_actual;
                                Message msg = handler.obtainMessage(
                                        MSG_CALCUL, (Object) Messagetosend);
                                handler.sendMessage(msg);
                            }
                        }
                    }
                }
            }
            handler.postDelayed(r, 5000);
        }
    };

}