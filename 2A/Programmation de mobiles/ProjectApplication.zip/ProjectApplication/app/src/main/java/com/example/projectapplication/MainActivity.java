package com.example.projectapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    /* BluetoothAdapter pour établir la connexion physique. */
    BluetoothAdapter bluetoothAdapter;
    BluetoothDevice[] btArray;

    /* Thread qui manipule l'envoie du socket et la réception. */
    ConnectedThread connectedThread;

    /* L'UUID pour que les appareils peuvent s'identifier entre eux. */
    private static final UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");


    /**
     * La méthode onCreate() est appelée lorsque l'activité est créée.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // On récupère le bouton pour lancer le client.
        Button btnServeur = findViewById(R.id.btn_serveur);
        btnServeur.setOnClickListener(this);
        // On récupère le bouton pour lancer le serveur.
        Button btnClient = findViewById(R.id.btn_client);
        btnClient.setOnClickListener(this);
    }
    /* Affichage des message d'etablissement des connexions en cours. */
    @Override
    public void onClick(View v) {
        /* Les composantes de l'interface. */
        Button btnServeur = findViewById(R.id.btn_serveur);
        Button btnClient = findViewById(R.id.btn_client);
        TextView textview =  findViewById(R.id.textView);
        int i = 0;
        switch (v.getId()) {

            // Partie traitement serveur
            case R.id.btn_serveur:
                // Faire disparaître le bouton client
                btnClient.setVisibility(View.INVISIBLE);
                // Changer le texte affiché dans le button du servuer
                btnServeur.setText("SERVEUR EN ATTENTE");
                // Changer le texte view afficher dans l'application
                textview.setText("* ATTENTE CONNECTION CLIENT *");
                // Appeler la classe du serveur
                AcceptThread serverClass = new AcceptThread();
                serverClass.start();
                break;

            // Partie traitement client
            case R.id.btn_client:
                // Cacher le button du serveur
                btnServeur.setVisibility(View.INVISIBLE);
                // Changer le texte affiché dans le button du client
                btnClient.setText("CLIENT SE CONNECTE");
                // Changer le texte view afficher dans l'application
                textview.setText("* ATTENTE CONNECTION SERVEUR *");
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                Set<BluetoothDevice> bt = bluetoothAdapter.getBondedDevices();
                //String[] strings = new String[bt.size()];
                btArray = new BluetoothDevice[bt.size()];


                if ((bt).size() > 0) {
                    for (BluetoothDevice device : bt) {
                        btArray[i]= device;
                        i++;
                    }
                    //ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(),
                            //android.R.layout.simple_list_item_1, strings);
                }
                // Appeler la classe du client
                ClientClass clientClass = new ClientClass(btArray[0]);
                // Provoque le changement, par le système d'exploitation,
                // de l'état de l'instance actuelle en Running.
                clientClass.start();
                break;
        }
        //Création d'une Intent
        Intent playIntentS = new Intent(this, firstActivity.class);
        // Ajout d’un parametre à l'intent
        startActivity(playIntentS);
    }


    public static class SocketHandler {

        private static BluetoothSocket socket;

        //public static synchronized BluetoothSocket getSocket() {
            //return socket;
       // }

        public static synchronized void setSocket(BluetoothSocket socket) {
            SocketHandler.socket = socket;
        }
    }


    /**
     * Le Thread de Socket Serveur pour recevoir les connexions envoyé par autre Socket Client.
     */
    private class AcceptThread extends Thread {
        private BluetoothServerSocket serverSocket;

        public AcceptThread() {
            // Création d'un socket serveur.
            BluetoothServerSocket tmp = null;
            try {
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                tmp = bluetoothAdapter.listenUsingRfcommWithServiceRecord("BLUETOOTH", uuid);
            } catch (IOException e) {
                e.printStackTrace();
            }
            serverSocket = tmp;
        }

        public void run() {
            BluetoothSocket socket = null;
            /* Tant que le socket n'est pas accepté. */
            while (true) {
                try {
                    // Retourner un socket si la connexion et établit avec le client.
                    socket = serverSocket.accept();
                    SocketHandler.setSocket(socket);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                //  Si la connexion est acceptée.
                if (socket != null) {
                    // On ferme le socket serveur.
                    try {
                        serverSocket.close();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    connectedThread = new ConnectedThread(socket);
                    connectedThread.start();
                    break;
                }
            }
        }
    }


    /**
     * Le Thread pour le Socket Client de faire la connexion à autre Socket Serveur.
     */
    private class ClientClass extends Thread {
        private final BluetoothDevice mmDevice;
        private BluetoothSocket socket;

        public ClientClass(BluetoothDevice device) {
            BluetoothSocket tmp = null;
            mmDevice = device;
            // Obtenez un BluetoothSocket pour vous connecter avec le BluetoothDevice donné.
            try {
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                tmp = device.createRfcommSocketToServiceRecord(uuid);
            } catch (IOException e) {
                e.printStackTrace();
            }
            socket = tmp;
        }

        public void run() {
            if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            bluetoothAdapter.cancelDiscovery();
            try {
                socket.connect();
            } catch (IOException connectException) {
                connectException.printStackTrace();
                try {
                    socket.close();
                } catch (IOException closeException) {
                    closeException.printStackTrace();
                }
                return;
            }
            connectedThread = new ConnectedThread(socket);
            connectedThread.start();
        }
    }


    /**
     * Le Thread pour envoyer les messages (par Bytes).
     */
    private static class ConnectedThread extends Thread {
        private final BluetoothSocket bluetoothSocket;
        private final InputStream inputStream;
        private final OutputStream outputStream;

        public ConnectedThread(BluetoothSocket socket) {
            bluetoothSocket = socket;
            InputStream temponIn = null;
            OutputStream temponOut = null;

            try {
                temponIn = bluetoothSocket.getInputStream();
                temponOut = bluetoothSocket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }

            inputStream = temponIn;
            outputStream = temponOut;
        }

        public void run() {
            byte[] buffer = new byte[1024];
            int bytes;

            while (true) {
                try {
                    bytes = inputStream.read(buffer);
                    // conversion en String
                } catch (IOException e) {
                    e.printStackTrace();
                    break;
                }
            }
        }

        public void write(byte[] bytes) {
            try {
                outputStream.write(bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}